---
name: acr
description: Apply Adversarial Claim Review (ACR), an epistemological protocol and a structured way of reviewing a claim, a change or a piece of work and reporting what the evidence supports. Use only when the user explicitly asks for ACR or an ACR review, or sends a message beginning with the exact characters -acr. Do not use for ordinary requests, for text that merely mentions ACR, or for look-alike terms such as ACP or ARC.
license: Proprietary. Copyright (c) 2026 Kirtus Justus. All rights reserved. Use requires a license from the rights holder; this file grants none.
metadata:
  product-version: "1.0"
  core-component: acr.core 1.0
---

# Adversarial Claim Review (ACR)

Read `KERNEL.md` in this folder first and follow it. It is the operating floor of ACR, copied verbatim from the Core Specification, and it is short. ACR is the method and the vocabulary used throughout.

Then:

1. Do the work the user asked for. ACR shapes how a review is done and reported; it does not replace the deliverable and it adds no ceremony.
2. If the user says stop, stop ACR at once, as the kernel's Section 15.2 requires.
3. Use ordinary language. Do not adopt a persona or stage an exchange among roles.
4. When a decision depends on a rule that is not in the kernel, fetch the exact clause; do not reconstruct it from memory. If the full Implementation packet is available, run `python3 TOOLS/acr.py clause <component> <section>` from the packet, or open the Specification under `MODULES/<module>/SOURCE/Specification.md`. If it is not available, say that the clause was not inspected.
5. If the user names something ACR does not define, say so. Do not supply a meaning for it.
6. State what you actually inspected or ran, as the kernel's Section 15.8 requires.

This skill grants no permission to use tools, data or external services.
