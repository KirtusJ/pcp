#!/usr/bin/env python3
"""Reference parser for the optional ACR command profile ACR-TEXT-2.

Parsing only. This program does not authenticate a caller, decide source
eligibility, interpret a request body, check permission or apply any effect.
Standard library only. See SUPPLEMENTS/Core_Conditional/Command_Interface.md.
"""
from __future__ import annotations
import json, sys, unicodedata

PROFILE = "ACR-TEXT-2"
PREFIX = "-acr"
MAX_BYTES = 8192
VIEWS = ("status", "settings", "permissions", "limits")
PROCEDURES = ("SCREENING", "FOCUSED", "FULL")
METHODS = tuple("M%02d" % i for i in range(1, 12))
STOP_WORDS = ("stop", "pause", "exit", "quit", "end", "cancel", "abort", "halt")
OPERATIONS = ("help", "show", "set", "request", "halt")
_DASHES = "\u2010\u2011\u2012\u2013\u2014\u2015\u2212\ufe58\ufe63\uff0d"


def _result(status, **kw):
    out = {"profile": PROFILE, "status": status, "effect": "NONE_PARSING_ONLY",
           "source_eligibility": "NOT_ASSESSED", "permission": "NOT_ASSESSED"}
    out.update(kw)
    return out


def _edit_distance_le1(a, b):
    if a == b:
        return True
    la, lb = len(a), len(b)
    if abs(la - lb) > 1:
        return False
    if la == lb:
        diff = [i for i in range(la) if a[i] != b[i]]
        if len(diff) == 1:
            return True
        return (len(diff) == 2 and diff[1] == diff[0] + 1
                and a[diff[0]] == b[diff[1]] and a[diff[1]] == b[diff[0]])
    if la > lb:
        a, b, la, lb = b, a, lb, la
    for i in range(lb):
        if b[:i] + b[i + 1:] == a:
            return True
    return False


def near_miss(text):
    """Informational only: does the text begin with something that resembles,
    but is not, the exact prefix? A near-miss invokes nothing (Core 15.6)."""
    stripped = text.lstrip(" \t\r\n\ufeff\u00a0")
    if not stripped:
        return False
    head = stripped.split(None, 1)
    token = head[0]
    rest = head[1] if len(head) > 1 else ""
    for sep in (":", "=", ",", ";"):
        token = token.split(sep, 1)[0] or token
    norm = "".join("-" if ch in _DASHES else ch for ch in token).casefold()
    exact_here = text.startswith(PREFIX) and (len(text) == len(PREFIX) or text[len(PREFIX)] == " ")
    if exact_here:
        return False
    if norm in ("acr", "/acr", "\\acr", "--acr", "_acr", ".acr", "!acr"):
        first = rest.split(None, 1)[0].casefold() if rest.split() else ""
        return norm != "acr" or first in OPERATIONS
    if norm.startswith(PREFIX) and norm[len(PREFIX):] in OPERATIONS:
        return True
    return _edit_distance_le1(norm, PREFIX)


def parse(message):
    """Return a parse result for one original host message (str or bytes)."""
    if isinstance(message, (bytes, bytearray)):
        raw = bytes(message)
        try:
            text = raw.decode("utf-8", errors="strict")
        except UnicodeDecodeError:
            if raw.startswith(PREFIX.encode()) and (len(raw) == 4 or raw[4:5] == b" "):
                return _result("REJECTED", reason="invalid UTF-8")
            return _result("NOT_COMMAND", near_miss=False)
    elif isinstance(message, str):
        text = message
        try:
            raw = text.encode("utf-8", errors="strict")
        except UnicodeEncodeError:
            if text.startswith(PREFIX) and (len(text) == 4 or text[4] == " "):
                return _result("REJECTED", reason="unpaired surrogate")
            return _result("NOT_COMMAND", near_miss=False)
    else:
        raise TypeError("message must be str or bytes")

    recognized = text.startswith(PREFIX) and (len(text) == len(PREFIX) or text[len(PREFIX)] == " ")
    if not recognized:
        nm = near_miss(text)
        out = _result("NOT_COMMAND", near_miss=nm)
        if nm:
            out["note"] = ("Not the exact prefix; nothing was invoked. The prefix is the four ASCII "
                           "characters -acr at the very start of the message, then a space or the end.")
        return out
    if len(raw) > MAX_BYTES:
        return _result("REJECTED", reason="message exceeds 8192 UTF-8 bytes")
    if text == PREFIX or text == PREFIX + " help":
        return _result("PARSED", operation="help")
    rest = text[len(PREFIX) + 1:]
    if rest == "halt":
        return _result("PARSED", operation="halt",
                       note="Takes effect at once under Core 15.2 only if the source is the host or the principal.")
    if rest == "show":
        return _result("PARSED", operation="show", view="status")
    if rest.startswith("show "):
        view = rest[5:]
        if view in VIEWS:
            return _result("PARSED", operation="show", view=view)
        return _result("REJECTED", reason="unknown or malformed view")
    if rest.startswith("set "):
        arg = rest[4:]
        if arg.startswith("procedure=") and arg[10:] in PROCEDURES:
            return _result("PARSED", operation="set", setting="procedure", value=arg[10:],
                           note="A set command requests a change; it does not apply one.")
        if arg.startswith("method.") and arg[7:10] in METHODS and arg[10:11] == "=" and arg[11:] in ("ON", "OFF"):
            return _result("PARSED", operation="set", setting="method." + arg[7:10], value=arg[11:],
                           note="A set command requests a change; it does not apply one.")
        return _result("REJECTED", reason="unknown or malformed setting")
    if rest.startswith("request "):
        body = rest[8:]
        for ch in body:
            if ch == "\n":
                continue
            if unicodedata.category(ch) in ("Cc", "Cs"):
                return _result("REJECTED", reason="control character in request body")
        if not any(not ch.isspace() for ch in body):
            return _result("REJECTED", reason="empty request body")
        return _result("PARSED_NEEDS_RESOLUTION", operation="request", body=body)
    out = _result("REJECTED", reason="unknown or malformed command")
    if rest.strip().casefold() in STOP_WORDS:
        out["expresses_stop"] = True
        out["note"] = ("Rejected as a command. The command spelling is '-acr halt'. If the source is the host "
                       "or the principal, the text is still an ordinary instruction to stop under Core 15.2.")
    return out


def main(argv=None):
    data = sys.stdin.buffer.read()
    if data.endswith(b"\n") and not (argv and "--keep-newline" in argv):
        data = data[:-1]
    print(json.dumps(parse(data), indent=2, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
