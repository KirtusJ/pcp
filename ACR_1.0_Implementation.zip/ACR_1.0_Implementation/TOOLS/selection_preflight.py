#!/usr/bin/env python3
"""Uniform, nonauthorizing input-shape preflight for the ACR specialist modules found in this packet."""
from __future__ import annotations
import json,sys,argparse,math,unicodedata
from pathlib import Path

import acr
SPECIALISTS={cid for key,(cid,_path) in acr.COMPONENTS.items() if key!='core'}
class Invalid(ValueError):pass
def require(x,msg):
 if not x:raise Invalid(msg)
def nonblank(s):
 return type(s) is str and any(not ch.isspace() and unicodedata.category(ch)[0] != "C" for ch in s)
def parse(s):
 def hook(pairs):
  d={}
  for k,v in pairs:
   require(k not in d,'duplicate key');d[k]=v
  return d
 def bad(v):raise Invalid('nonfinite literal')
 def fin(v):
  n=float(v);require(math.isfinite(n),'nonfinite float');return n
 return json.loads(s,object_pairs_hook=hook,parse_constant=bad,parse_float=fin)
def preflight(rec):
 require(type(rec) is dict,'task record must be object')
 require(nonblank(rec.get('principal')) and nonblank(rec.get('task_scope')),'principal and task scope required')
 require(rec.get('selection_basis') in ('AUTHORIZED_TASK','GOVERNING_POLICY'),'identified selection basis required')
 sel=rec.get('selected_components')
 require(type(sel) is list and all(type(v) is str for v in sel),'selected_components must be strings')
 require(len(set(sel))==len(sel),'duplicate selected components')
 require(bool(sel) and sel[0]=='acr.core','Core required in first position for this preflight profile')
 require(set(sel)<=SPECIALISTS|{'acr.core'},'unknown specialist component')
 require(type(rec.get('high_consequence',False)) is bool,'high consequence must be Boolean')
 require(type(rec.get('effects_requested',False)) is bool,'effects requested must be Boolean')
 bases=rec.get('specialist_bases',{})
 require(type(bases) is dict,'specialist bases must be object')
 chosen=set(sel)-{'acr.core'}
 require(set(bases)==chosen,'specialist bases must match exactly selected specialists')
 for k,v in bases.items():
  require(type(v) is dict and nonblank(v.get('scope')) and nonblank(v.get('basis_reference')),'invalid basis record for '+k)
 return {'result':'CALLER_RECORD_SHAPE_ACCEPTED','selection_basis':rec['selection_basis'],'caller_declared_selected_components':sel,
 'claimed_evidence_authenticated':False,'actual_checks_performed':'NOT_VERIFIED','specialist_methodology':'NOT_ASSESSED',
 'runtime_authorization':'NOT_CHECKED_NOT_GRANTED','operational_deployment':'NO_GO_FROM_THIS_PREFLIGHT',
 'message':'These inputs describe a claimed selection; this tool neither commissions modules nor authorizes effects.'}
def main():
 a=argparse.ArgumentParser();a.add_argument('record');args=a.parse_args()
 try:
  p=Path(args.record)
  require(p.is_file() and p.stat().st_size<200000,'record missing or oversized')
  print(json.dumps(preflight(parse(p.read_text())),indent=2));return 0
 except (Invalid,OSError,ValueError,TypeError,json.JSONDecodeError) as e:
  print(json.dumps({'result':'INPUT_REJECTED','reason':str(e)}));return 1
if __name__=='__main__':sys.exit(main())
