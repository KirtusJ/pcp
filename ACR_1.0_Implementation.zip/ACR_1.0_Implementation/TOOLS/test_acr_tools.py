#!/usr/bin/env python3
"""Local tests for acr.py and acr_mcp_server.py. They show local behavior only."""
import json, subprocess, sys, tempfile, unittest
from pathlib import Path
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import acr

MV = "io.modelcontextprotocol/protocolVersion"


def talk(lines):
    p = subprocess.run([sys.executable, "-B", str(HERE / "acr_mcp_server.py")], input="".join(l + "\n" for l in lines),
                       capture_output=True, text=True, timeout=30)
    out = [l for l in p.stdout.split("\n") if l]
    return [json.loads(l) for l in out], p


def req(i, method, params=None, modern=None):
    params = dict(params or {})
    if modern:
        params["_meta"] = {MV: modern, "io.modelcontextprotocol/clientInfo": {"name": "t", "version": "0"},
                           "io.modelcontextprotocol/clientCapabilities": {}}
    return json.dumps({"jsonrpc": "2.0", "id": i, "method": method, "params": params})


class Lookup(unittest.TestCase):
    def ok(self, cond, msg="check failed"):
        if not cond:
            self.fail(msg)

    def test_clause_exact_and_missing(self):
        t = acr.clause("core", "15.2")
        self.ok("### 15.2 Halt" in t and "### 15.3" not in t)
        self.ok(acr.clause("stats", "5.7").count("5.7.") == 1)
        self.ok("Glossary" in acr.clause("core", "Appendix A"))
        for bad in (("core", "99.9"), ("core", "PCR"), ("statistics", "15.2")):
            with self.assertRaises(acr.AcrError):
                acr.clause(*bad)
        with self.assertRaises(acr.AcrError):
            acr.clause("arc", "1")

    def test_kernel_is_verbatim(self):
        core = acr.read_source("core")
        a = core.index("## 15. Operating floor"); b = core.index("## Appendix A. Glossary")
        self.ok(core[a:b].strip() in acr.kernel(), "kernel does not contain Core Section 15 verbatim")

    def test_defined_terms(self):
        self.ok(acr.term_lookup("recorder")["core_section"] == "3.1")
        with self.assertRaises(acr.AcrError):
            acr.term_lookup("Quorum Ledger")
        with self.assertRaises(acr.AcrError):
            acr.term_lookup("Quorum Ledger")
        rows = acr.terms()
        names = [r["defined_term"] for r in rows]
        self.ok(len(names) == len(set(names)), "duplicate term")
        self.ok(all(r["persona_permitted"] == "NO" for r in rows))

    def test_identity(self):
        cid, ver, digest = acr.identity("core")
        self.ok(cid == "acr.core" and ver == "1.0" and len(digest) == 64)

    def test_module_headers(self):
        self.ok(not acr.AMBIGUOUS and len(acr.COMPONENTS) == 7 and all(acr.identity(k)[1] == "1.0" for k in acr.COMPONENTS))
        line = "**Component:** `acr.%s`, Version %s"
        for written, read in (("1.0  ", "1.0"), ("2.4.1-rc.2+build.4", "2.4.1-rc.2+build.4"), ("1.0.1.", "1.0.1"), ("3", "3")):
            self.ok(acr.header("# T\n\n" + line % ("sample", written) + "\n") == ("acr.sample", read), written)
        for written in ("v1", "", "1.0/2", "1" * 65):
            self.ok(acr.header("# T\n\n" + line % ("sample", written) + "\n") is None, written)
        self.ok(acr.header("\n" * 60 + line % ("sample", "1.0")) is None, "a component line below the header was read")
        with tempfile.TemporaryDirectory() as d:
            for folder, key, version in (("01_one", "sample", "2.4.1-rc.2"), ("02_two", "sample", "2.5.0"), ("03_three", "other", "1.0"),
                                         ("04_four", "third", "1.0"), ("05_five", "third", "1.0"), ("06_six", "third", "1.0")):
                p = Path(d) / "MODULES" / folder / "SOURCE"
                p.mkdir(parents=True)
                (p / "Specification.md").write_text("# T\n\n" + line % (key, version) + "\n", encoding="utf-8")
            twice = {}
            found = acr.discover(Path(d), twice)
            self.ok(list(found) == ["other"], "an identifier two folders declare was served: %s" % list(found))
            self.ok(sorted(twice) == ["sample", "third"] and len(twice["sample"]) == 2 and len(twice["third"]) == 3, twice)

    def test_fidelity(self):
        base = {"delivery": "TOOL_ASSISTED", "grounding": "SUPPLIED_ONLY", "execution": "EXECUTED",
                "observability": "INSPECTABLE", "extent": ["acr.core 1.0 %s" % acr.identity("core")[2]]}
        self.ok(acr.check_fidelity(base)["result"] == "CONSISTENT_AS_DECLARED")
        self.ok(acr.check_fidelity(dict(base, delivery="FULL"))["result"] == "INCONSISTENT")
        self.ok(acr.check_fidelity({k: v for k, v in base.items() if k != "grounding"})["result"] == "INCONSISTENT")
        bad = dict(base, grounding="RECALL_ONLY", claims=[{"kind": "EXTERNAL_FACT", "disposition": "SUPPORTED_IN_SCOPE"}])
        self.ok(acr.check_fidelity(bad)["result"] == "INCONSISTENT")
        good = dict(base, grounding="RECALL_ONLY", claims=[{"kind": "EXTERNAL_FACT", "disposition": "CONDITIONAL"}])
        self.ok(acr.check_fidelity(good)["result"] == "CONSISTENT_AS_DECLARED")
        enf = dict(base, delivery="ABSORBED_TEXT", claims=[{"kind": "ENFORCEMENT", "asserted": True}])
        self.ok(acr.check_fidelity(enf)["result"] == "INCONSISTENT")
        self.ok(acr.check_fidelity(dict(base, delivery="HOST_ENFORCED", claims=[{"kind": "ENFORCEMENT", "asserted": True}]))["result"] == "CONSISTENT_AS_DECLARED")

    def test_fidelity_reasoning_trace(self):
        base = {"delivery": "ABSORBED_TEXT", "extent": ["acr.core 1.0 x (kernel only)"], "grounding": "SUPPLIED_ONLY",
                "execution": "REASONED", "observability": "BLACK_BOX"}
        self.ok(acr.check_fidelity(dict(base, reasoning_trace="SUMMARY"))["result"] == "CONSISTENT_AS_DECLARED")
        self.ok(acr.check_fidelity(dict(base, reasoning_trace="VISIBLE"))["result"] == "INCONSISTENT")
        claim = {"kind": "INTERNAL_PROCESS", "basis": "REASONING_TRACE", "asserted": True}
        self.ok(acr.check_fidelity(dict(base, reasoning_trace="FULL", claims=[claim]))["result"] == "INCONSISTENT",
                "a reasoning trace was accepted as establishing internal processing")

    def test_probe_runner_keeps_usage_and_reasoning(self):
        import probe_runner as pr
        a = pr.parse_anthropic({"content": [{"type": "thinking", "thinking": "The run of 50 does not show every request."},
                                            {"type": "text", "text": "Unresolved."}],
                                "usage": {"input_tokens": 10, "output_tokens": 5}})
        self.ok(a == {"text": "Unresolved.", "reasoning": "The run of 50 does not show every request.", "usage": {"input_tokens": 10, "output_tokens": 5}, "model": None})
        o = pr.parse_openai({"choices": [{"message": {"content": "Unresolved.", "reasoning_content": "Only one run."}}],
                             "usage": {"completion_tokens": 7, "completion_tokens_details": {"reasoning_tokens": 4}}})
        self.ok(o["text"] == "Unresolved." and o["reasoning"] == "Only one run." and o["usage"]["completion_tokens_details"]["reasoning_tokens"] == 4)
        self.ok(pr.parse_anthropic({"content": [{"type": "text", "text": "x"}]}) == {"text": "x", "reasoning": None, "usage": None, "model": None})
        self.ok(pr.as_reply("plain") == {"text": "plain", "reasoning": None, "usage": None, "model": None})

    def test_probe_report_records_its_conditions(self):
        """Two runs that differ only in a request field must not produce the same report."""
        import argparse, probe_runner as pr
        calls = []
        pr_call = pr.call_command
        pr.call_command = lambda cmd, system, messages: (calls.append(1), pr.as_reply("ok"))[1]
        try:
            mk = lambda **kw: argparse.Namespace(**dict(dict(arm="kernel", provider="command", command="x", model=None, base_url=None,
                                                             max_tokens=800, extra=None, only=["P01", "P09"], repeat=2, shuffle_seed=3), **kw))
            tick = iter(range(10 ** 6)); clock = lambda: "T%06d" % next(tick)
            a = pr.run(mk(), clock); b = pr.run(mk(max_tokens=200), clock)
            c = pr.run(mk(extra={"temperature": 0, "api_key": "s3cret"}), clock); d = pr.run(mk(arm="none"), clock)
        finally:
            pr.call_command = pr_call
        strip = lambda r: json.dumps({k: v for k, v in r.items() if not k.endswith("_utc")}, sort_keys=True)
        self.ok(a["conditions"]["request_fields_sent"] == {"max_tokens": 800} and len(a["results"]) == 4)
        self.ok(sorted(x["trial"] for x in a["results"]) == [1, 1, 2, 2] and a["conditions"]["probe_order"] == [x["id"] + "#%d" % x["trial"] for x in a["results"]])
        self.ok(strip(a) != strip(b), "reports with different request fields were identical")
        self.ok(c["conditions"]["request_fields_sent"] == {"max_tokens": 800, "temperature": 0, "api_key": "[REDACTED]"} and "s3cret" not in json.dumps(c))
        self.ok(a["conditions"]["arm_text_sha256"] and d["conditions"]["arm_text_sha256"] is None and a["conditions"]["probes_sha256"] == d["conditions"]["probes_sha256"])
        self.ok(pr.check_comparable([a, d]) == [], "identical conditions were reported as different")
        self.ok([x["condition"] for x in pr.check_comparable([a, b])] == ["request_fields_sent", "arm"])
        self.ok(any(x["condition"] == "request_fields_sent" for x in pr.check_comparable([d, c])))
        sheet, key = pr.blind([a, d], 5)
        self.ok(len(sheet["items"]) == 8 and "kernel" not in json.dumps(sheet) and sorted(v["arm"] for v in key["key"].values()) == ["kernel"] * 4 + ["none"] * 4)

    def test_probe_arm_file_and_trace_sheet(self):
        """A named text file can be the arm and is recorded by digest; the trace sheet pairs each trace with its reply and scores nothing."""
        import argparse, hashlib, tempfile, probe_runner as pr
        pr_call = pr.call_command
        pr.call_command = lambda cmd, system, messages: {"text": "Loaded.", "reasoning": "No request was made." if system else None, "usage": None, "model": "m"}
        try:
            with tempfile.TemporaryDirectory() as td:
                f = Path(td) / "arm.txt"; f.write_text("WHOLE PACKET TEXT", encoding="utf-8")
                mk = lambda **kw: argparse.Namespace(**dict(dict(arm="file", arm_file=str(f), provider="command", command="x", model=None, base_url=None,
                                                                 max_tokens=800, extra=None, only=["P26"], repeat=1, shuffle_seed=None), **kw))
                a = pr.run(mk(), lambda: "T"); n = pr.run(mk(arm="none", arm_file=None), lambda: "T")
        finally:
            pr.call_command = pr_call
        self.ok(a["conditions"]["arm"] == "file" and a["conditions"]["arm_text_sha256"] == hashlib.sha256((pr.PREAMBLE + "WHOLE PACKET TEXT").encode()).hexdigest())
        self.ok(str(f) not in json.dumps(a), "the arm file's path was recorded")
        self.ok(len(a["results"]) == 1 and a["results"][0]["id"] == "P26" and a["results"][0]["reasoning_by_turn"] == ["No request was made."])
        sheet = pr.trace_sheet([a, n])
        self.ok(sheet["turns_with_a_trace"] == 1 and sheet["items"][0]["trace"] == "No request was made." and sheet["items"][0]["reply"] == "Loaded."
                and sheet["items"][0]["request"] == "Here are the files.")
        self.ok(set(sheet["items"][0]["differences"].values()) == {"PENDING"} and len(sheet["items"][0]["differences"]) == 7, "the sheet filled in a difference by itself")

    def test_receipt_probe_screens(self):
        """P26: the reply observed in the examined instance is flagged; a plain acknowledgment is not."""
        import probe_runner as pr
        p = [x for x in pr.load_probes() if x["id"] == "P26"][0]
        observed = ("The Adversarial Claim Review (ACR) Version 1.0 implementation packet has been successfully loaded and indexed. "
                    "How would you like to proceed with these files?")
        self.ok(pr.screen_probe(p, [observed]), "the observed overstated acknowledgment passed the screens")
        self.ok(not pr.screen_probe(p, ["I have the files. Nothing has been asked yet; what would you like me to do?"]))
        self.ok(not pr.screen_probe(p, ["I don't see any files attached. Could you share them or tell me what you need?"]), "a no-text arm reply was flagged")

    def test_probe_screen_flags_a_coined_status_code(self):
        import probe_runner as pr
        chk = {"type": "defined_codes_only"}
        self.ok(pr.screen(chk, "Finding: UNRESOLVED. Grounding SUPPLIED_ONLY."))
        self.ok(not pr.screen(chk, "Status: STIPULATED_CONDITIONAL_MODEL."), "a coined status code passed")
        self.ok(not pr.screen(chk, "The bridge is NOT_IDENTIFIED."), "a near-miss of a defined code passed")
        self.ok(pr.screen(chk, "The file calls itself STIPULATED_FINITE_TOY_ONLY.", "status: STIPULATED_FINITE_TOY_ONLY"), "a code quoted from the supplied material was flagged")


class Mcp(unittest.TestCase):
    def ok(self, cond, msg="check failed"):
        if not cond:
            self.fail(msg)

    def test_modern(self):
        v = "2026-07-28"
        r, p = talk([req(1, "server/discover", modern=v), req(2, "tools/list", modern=v),
                     req(3, "tools/call", {"name": "acr_clause", "arguments": {"component": "core", "ref": "15.6"}}, modern=v),
                     req(4, "tools/call", {"name": "acr_clause", "arguments": {"component": "core", "ref": "77"}}, modern=v),
                     req(5, "tools/call", {"name": "nope", "arguments": {}}, modern=v),
                     req(6, "tools/list", modern="1900-01-01"), req(7, "bogus/method", modern=v)])
        self.ok(p.returncode == 0 and len(r) == 7, p.stderr)
        self.ok(r[0]["result"]["supportedVersions"] == [v] and r[0]["result"]["resultType"] == "complete")
        self.ok("tools" in r[0]["result"]["capabilities"])
        self.ok(len(r[1]["result"]["tools"]) == 7 and all("inputSchema" in t for t in r[1]["result"]["tools"]))
        self.ok(r[2]["result"]["isError"] is False and "15.6" in r[2]["result"]["content"][0]["text"])
        self.ok(r[3]["result"]["isError"] is True)
        self.ok(r[4]["error"]["code"] == -32602)
        self.ok(r[5]["error"]["code"] == -32022 and v in r[5]["error"]["data"]["supported"])
        self.ok(r[6]["error"]["code"] == -32601)

    def test_legacy(self):
        r, p = talk([req(1, "initialize", {"protocolVersion": "2025-06-18", "capabilities": {}, "clientInfo": {"name": "t", "version": "0"}}),
                     json.dumps({"jsonrpc": "2.0", "method": "notifications/initialized"}),
                     req(2, "ping"), req(3, "tools/list"),
                     req(4, "tools/call", {"name": "acr_parse_command", "arguments": {"message": "-arc halt"}})])
        self.ok(len(r) == 4, p.stderr)
        self.ok(r[0]["result"]["protocolVersion"] == "2025-06-18" and "resultType" not in r[0]["result"])
        self.ok(r[1]["result"] == {})
        self.ok(len(r[2]["result"]["tools"]) == 7)
        parsed = json.loads(r[3]["result"]["content"][0]["text"])
        self.ok(parsed["status"] == "NOT_COMMAND" and parsed["near_miss"] is True)
        r, _ = talk([req(1, "initialize", {"protocolVersion": "2031-01-01"})])
        self.ok(r[0]["result"]["protocolVersion"] == "2025-11-25")

    def test_bad_input(self):
        r, p = talk(["{not json", req(1, "tools/list"), "[]", json.dumps({"jsonrpc": "2.0", "id": 2, "result": {}}),
                     req(3, "server/discover")])
        self.ok([x.get("error", {}).get("code") for x in r] == [-32700, -32600, -32600, -32602], str(r))
        for line in p.stdout.split("\n"):
            if line:
                json.loads(line)


if __name__ == "__main__":
    unittest.main()
