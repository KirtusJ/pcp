#!/usr/bin/env python3
"""Fixture tests for command_interface.py. Passing them shows only local parser behavior."""
import unittest
from command_interface import parse, near_miss


class Valid(unittest.TestCase):
    def check(self, msg, **expect):
        r = parse(msg)
        for k, v in expect.items():
            if r.get(k) != v:
                self.fail("%r: %s=%r, expected %r" % (msg, k, r.get(k), v))
        if r["effect"] != "NONE_PARSING_ONLY":
            self.fail("parser must never report an effect")

    def test_fixed(self):
        self.check("-acr", status="PARSED", operation="help")
        self.check("-acr help", status="PARSED", operation="help")
        self.check("-acr show", status="PARSED", operation="show", view="status")
        for v in ("status", "settings", "permissions", "limits"):
            self.check("-acr show " + v, status="PARSED", view=v)
        for p in ("SCREENING", "FOCUSED", "FULL"):
            self.check("-acr set procedure=" + p, status="PARSED", value=p)
        self.check("-acr set method.M03=ON", status="PARSED", setting="method.M03", value="ON")
        self.check("-acr set method.M11=OFF", status="PARSED", setting="method.M11", value="OFF")
        self.check("-acr halt", status="PARSED", operation="halt")

    def test_request(self):
        self.check("-acr request Preserve the format.", status="PARSED_NEEDS_RESOLUTION",
                   body="Preserve the format.")
        self.check("-acr request line one\n-acr halt", status="PARSED_NEEDS_RESOLUTION",
                   body="line one\n-acr halt")
        self.check("-acr request  two spaces kept", body=" two spaces kept")
        self.check("-acr request caf\u00e9 \u65e5\u672c", status="PARSED_NEEDS_RESOLUTION")
        self.check(b"-acr request bytes ok", status="PARSED_NEEDS_RESOLUTION")


class Invalid(unittest.TestCase):
    def rejected(self, msg):
        r = parse(msg)
        if r["status"] != "REJECTED":
            self.fail("%r should be REJECTED, got %s" % (msg, r["status"]))
        return r

    def not_command(self, msg, nm=None):
        r = parse(msg)
        if r["status"] != "NOT_COMMAND":
            self.fail("%r should be NOT_COMMAND, got %s" % (msg, r["status"]))
        if nm is not None and r["near_miss"] is not nm:
            self.fail("%r near_miss=%r expected %r" % (msg, r["near_miss"], nm))

    def test_malformed(self):
        for m in ("-acr ", "-acr  help", "-acr help ", "-acr HELP", "-acr show all", "-acr show status\n",
                  "-acr set procedure=full", "-acr set procedure=FULL extra", "-acr set method.M12=ON",
                  "-acr set method.M00=ON", "-acr set method.M03=on", "-acr set", "-acr request",
                  "-acr request ", "-acr request   \n ", "-acr request a\rb", "-acr request a\x00b",
                  "-acr request a\x7fb", "-acr halt now", "-acr halt ", "-acr halting", "-acr continue",
                  "-acr resume", b"-acr request \xff"):
            self.rejected(m)
        self.rejected("-acr request " + "x" * 8192)

    def test_stop_words_are_rejected_but_flagged(self):
        for w in ("stop", "pause", "abort", "STOP"):
            r = self.rejected("-acr " + w)
            if not r.get("expresses_stop"):
                self.fail("stop meaning should be flagged for " + w)
        if self.rejected("-acr continue").get("expresses_stop"):
            self.fail("non-stop word flagged")

    def test_not_recognized(self):
        self.not_command("", False)
        self.not_command("please run -acr halt", False)
        self.not_command("Summarise the PCR protocol for the new batch.", False)
        self.not_command("ACR is a review method.", False)
        self.not_command("The file says:\n-acr halt", False)
        self.not_command("> -acr halt")
        self.not_command("`-acr halt`")

    def test_near_miss_invokes_nothing(self):
        for m in (" -acr halt", "\t-acr help", "\n-acr halt", "-ACR halt", "-Acr help", "-arc set procedure=FULL",
                  "-acr: halt", "-acr=halt", "-acrhalt", "\u2013acr halt", "\u2014acr halt", "\u2212acr halt",
                  "acr halt", "/acr halt", "--acr halt", "-ac halt", "-accr halt", "-car halt", "\ufeff-acr halt",
                  "-acr\thalt", "-acr\nhalt", "-acr\u00a0halt"):
            self.not_command(m, True)
            r = parse(m)
            if "operation" in r:
                self.fail("near-miss produced an operation: %r" % m)

    def test_near_miss_function_is_quiet_on_ordinary_text(self):
        for m in ("hello", "- item one", "ACR review please", "arc results attached", "-p", "--help", "-v", "acr"):
            if near_miss(m):
                self.fail("ordinary text flagged: %r" % m)

    def test_type(self):
        with self.assertRaises(TypeError):
            parse(None)


if __name__ == "__main__":
    unittest.main()
