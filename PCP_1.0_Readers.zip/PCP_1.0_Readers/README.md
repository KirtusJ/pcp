# PCP 1.0 | Readers packet | Enterprise Edition

**Parrot Council Protocol (PCP)** is the product name; the method inside it is **Adversarial Claim Review (ACR)**, an epistemological protocol: it specifies how a claim is examined and what its evidence is permitted to establish.

This packet holds typeset PDF reading copies of every source document, in the Enterprise Edition theme, with the brand identity. It is for people. Nothing in it is needed to use ACR, and nothing in it should be loaded into an assistant's context. The method itself is in `ACR_1.0_Implementation.zip`, supplied beside this packet. That packet is named ACR throughout: the product name does not appear in it, its tools and skill are named `acr`, and its command prefix is `-acr`.

A request for PCP is a request for ACR. An assistant that holds only the Implementation packet does not know the product name: it gives the name no ACR meaning and asks only if that would change what it does next. Where people will ask for the product by that name, add one sentence to the assistant's or host's own instructions: `In this deployment, "PCP" and "Parrot Council Protocol" are aliases for ACR.` The alias changes no rule and creates no command prefix; the prefix remains `-acr` (Core Specification, Sections 15.6 and 15.7).

Open **`START_HERE.pdf`** to begin, then `MODULES/01_Core/Overview.pdf`. Each module has an **Overview** (orientation) and a **Specification** (requirements). `EDITION/Edition_Guide.pdf` is the reading copy of this edition's guide. The Markdown sources in the Implementation packet govern wherever a reading copy differs.

The product's license, notice, price schedule and evidence statement are supplied beside this packet, at the top level of the edition (`LICENSE.md`, `NOTICE.md`, `PRICING.md`, `EVIDENCE_STATUS.md`). Each module cover carries one line of evidence status and refers to that statement.

`MANIFEST.json` lists every file here with its digest and, for each PDF, the source it was generated from and that source's digest. It pins the Implementation packet by the SHA-256 of its `MANIFEST.json`: `6b6d3a680f3fdec811ce7105dd2124e951e272c28a24608f073914f4155853c6`. `python3 verify_readers.py [path-to-Implementation-packet]` checks this packet and, when given the Implementation packet, that the source digests agree. A pass is a local fact about files; it authenticates nobody and certifies nothing.
