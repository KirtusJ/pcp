# PCP 1.0 | Brand and book identity | Enterprise Edition

**Product name:** Parrot Council Protocol (PCP). **Method name:** Adversarial Claim Review (ACR). **Category:** an epistemological protocol, which specifies how a claim is examined and what its evidence is permitted to establish. **Product version:** 1.0. **Creator:** Kirtus Justus. **Motto:** Evidence before agreement.

PCP is the brand under which the product is distributed. The product name appears in the edition's own documents and in this Readers packet. It does not appear in the Implementation packet, which is named ACR throughout.

## Two codes, kept apart

The covers carry two independent pieces of information, and each has its own visual code.

| What is coded | Carried by | Varies with |
| --- | --- | --- |
| The module | The emblem plate: one bird outline on the module's own color, with a mark on the wing | Module only |
| The edition | The cover field, the accent color of the rule, label and edition tag, and the color of headings, running heads and table headers inside the book | Edition only |

A reader can therefore tell the module from the plate and the edition from the page, and neither code has to be read through the other. The edition is also printed in words on every cover and in every running foot.

### The module plates

| Module | Plate color | Wing mark |
| --- | --- | --- |
| Core | Navy | Plain wing (the reference bird) |
| Mathematics | Burgundy | Two concentric arcs |
| Science | Sky blue | Ring with a center dot |
| Engineering | Orange | Two stacked chevrons |
| Cryptography | Purple | Keyhole |
| Statistics | White | Three rising bars |
| Quality Assurance | Lime | Check mark |

The plates are the same in every edition.

### The edition themes

| Edition | Field | Lightness (CIELAB L*) | Accent | Accent hue (CIELAB) | Heading color inside |
| --- | --- | --- | --- | --- | --- |
| Personal | Paper `#F6F0E4` | 95 | Amber `#A25600` | 64 degrees | `#8A4A00` |
| Commercial | Teal `#0F6B67` | 41 | Aqua `#A6F0E4` | 183 degrees | `#0C5F5B` |
| Enterprise | Ink `#16151F` | 7 | Violet `#B7A4F7` | 302 degrees | `#4B3A96` |

This packet uses the **Enterprise** theme.

The reasoning behind the three themes:

- **Lightness carries the edition first.** The three fields are light, middle and dark, at least 33 L* units apart. Lightness survives color-vision deficiency and grayscale printing, where hue does not.
- **Hue carries it a second time.** The three accent hues are about 120 degrees apart in CIELAB (64, 183 and 302 degrees), a triad. Two of the three come from the reference bird, whose body is teal and whose beak is amber; violet completes the triad.
- **The accents are tuned to their fields, not to each other.** On a light field the accent is a dark amber; on the two dark fields it is a light tint. Each therefore reads at the same strength against its own field.

### Measured, not assumed

| Check | Personal | Commercial | Enterprise |
| --- | --- | --- | --- |
| Cover text against field (contrast ratio) | 13.4 | 6.0 | 16.3 |
| Accent against field | 4.8 | 4.9 | 8.3 |
| Small print against field | 6.7 | 5.2 | 10.8 |
| Heading color against white page | 6.9 | 7.5 | 9.0 |
| White text on table header | 10.5 | 10.5 | 14.2 |

Every text pairing is at or above 4.5 to 1, the WCAG 2 level AA figure for body text. Under simulated protanopia, deuteranopia and tritanopia the three fields remain at least 31 color-difference units apart. These are computed figures for the stated colors on screen. No reader study, print proof or accessibility audit was performed, and a simulation is not a test with people.

## Boundaries

The bird emblem is brand artwork and appears only on covers. It is not a character and not a term of the protocol; Core Section 15.7 forbids an assistant from adopting any name as a persona. Neither a plate color nor an edition theme confers authority or changes content: every edition contains the same Implementation packet and the same document texts.

The cover credit lines are those of each module's source: "Protocol creator and owner" for Core, Mathematics, Science, Engineering and Cryptography, and "Protocol creator and research direction" for Statistics and Quality Assurance. A cover credit is not legal proof of exclusive ownership of a method. A module's professional references are not certification marks or evidence that a standards body endorses ACR.

Every component is Version 1.0. This packet's `MANIFEST.json` records, for each PDF, the source it was generated from and that source's digest, and pins the Implementation packet by the digest of its manifest. Every PDF in this packet was generated from its source.
