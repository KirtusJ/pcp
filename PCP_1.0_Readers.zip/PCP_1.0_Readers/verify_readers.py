#!/usr/bin/env python3
"""Local check for a PCP Version 1.0 Readers packet. Standard library only.

Checks the file inventory and digests against MANIFEST.json, that every PDF is a
complete container, and, if the Implementation packet directory is given, that
each PDF generated from an Implementation source records the digest of that
source there and that the Implementation manifest fingerprint matches the pin.
The edition guide's source lies beside this packet, at the top level of the
edition, and is checked by the edition's own verifier. A pass is a local fact
about these files; it authenticates nobody, validates no meaning and certifies nothing.
"""
import hashlib, json, sys
from pathlib import Path
HERE = Path(__file__).resolve().parent


def sha(b):
    return hashlib.sha256(b).hexdigest()


def main(argv):
    if argv and argv[0] in ("-h", "--help"):
        print(__doc__.strip()); print("usage: python3 verify_readers.py [path-to-Implementation-packet]"); return 0
    try:
        man = json.loads((HERE / "MANIFEST.json").read_text(encoding="utf-8"))
    except (OSError, ValueError) as e:
        print("FAIL_READERS_CHECK: MANIFEST.json unreadable: %s" % type(e).__name__); return 1
    if man.get("format") != "pcp-readers-local-integrity/2.0" or man.get("edition") not in ("PERSONAL", "COMMERCIAL", "ENTERPRISE"):
        print("FAIL_READERS_CHECK: unsupported manifest format or edition"); return 1
    files = {e["path"]: e for e in man["files"]}
    actual = sorted(p.relative_to(HERE).as_posix() for p in HERE.rglob("*")
                    if p.is_file() and p.name != "MANIFEST.json" and "__pycache__" not in p.parts)
    if actual != sorted(files) or man.get("payload_count") != len(files):
        print("FAIL_READERS_CHECK: inventory differs from manifest: %s" % sorted(set(actual) ^ set(files))[:5]); return 1
    for p, e in files.items():
        data = (HERE / p).read_bytes()
        if len(data) != e["bytes"] or sha(data) != e["sha256"]:
            print("FAIL_READERS_CHECK: content differs from manifest: %s" % p); return 1
        if p.endswith(".pdf") and not (data.startswith(b"%PDF-") and b"%%EOF" in data[-2048:]):
            print("FAIL_READERS_CHECK: incomplete PDF container: %s" % p); return 1
    if argv:
        impl = Path(argv[0]).resolve()
        if not (impl / "MANIFEST.json").is_file():
            print("FAIL_READERS_CHECK: no MANIFEST.json at %s; give the extracted Implementation packet directory" % impl); return 1
        im = (impl / "MANIFEST.json").read_bytes()
        if sha(im) != man["implementation_packet"]["manifest_sha256"]:
            print("FAIL_READERS_CHECK: Implementation manifest fingerprint differs from the pin"); return 1
        digest = {e["path"]: e["sha256"] for e in json.loads(im)["files"]}
        for p, e in files.items():
            if p.endswith(".pdf") and e.get("source_packet") == "IMPLEMENTATION":
                src = e["generated_from"]
                if digest.get(src) != e["source_sha256"] or sha((impl / src).read_bytes()) != e["source_sha256"]:
                    print("FAIL_READERS_CHECK: source digest for %s differs in the Implementation packet" % p); return 1
        print("PASS_READERS_CHECK %d files, %s edition; sources agree with the Implementation packet at %s" % (len(files), man["edition"], impl))
    else:
        print("PASS_READERS_CHECK %d files, %s edition (Implementation packet not given; source digests not compared)" % (len(files), man["edition"]))
    print("Readers fingerprint (SHA-256 of MANIFEST.json): %s" % sha((HERE / "MANIFEST.json").read_bytes()))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
