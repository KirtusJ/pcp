#!/bin/bash
set -eu
cd "$(dirname "$0")"
work=/workspace/scratch/7c7df1723510/work
source_os="$work/integrated307"
media="$work/a3-pcp-integration/media"
qemu="$work/emulator/qemu-system-x86_64"
case "$1" in
single|two-app)
    python3 src/audit/public-live-cd/check_host_boot.py "$media/$1/pcp-os-tester.iso" "observed-$1" --desktop-build "$source_os" "$media/$1/receipt.json" --qemu "$qemu"
    ;;
vm)
    python3 src/audit/vm-workspace/check.py "$media/workspace.zip" "$source_os" observed-vm --desktop-first --qemu "$qemu"
    ;;
esac
