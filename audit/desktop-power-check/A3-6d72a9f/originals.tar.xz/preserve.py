"""Collect this exact tester’s guest observations and check the archived bytes."""
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile

root = Path(__file__).resolve().parent
work = Path("/workspace/scratch/7c7df1723510/work")

def digest(path):
    with path.open("rb") as data:
        return hashlib.file_digest(data, "sha256").hexdigest()

def git(repo, ref):
    return subprocess.check_output(["git", "-C", repo, "rev-parse", ref], text=True).strip()

def read(path):
    return json.loads(path.read_bytes())

tester = git(root / "src", "HEAD")
os_source = git(work / "integrated307", "HEAD")
assert tester == "6d72a9fb538222afe4dd4fe5aad65958daadf7da"
assert os_source == "3e86beb1ee17fad2f3d61c95b9d5dd017fb6c755"
media = work / "a3-pcp-integration/media"
runs = {}
files = set()
for name in ["observed-single", "observed-two-app", "observed-vm/first", "observed-vm/cold"]:
    folder = root / name
    result = read(folder / "result.json")
    serial = (folder / "serial.txt").read_text().splitlines()
    end_startup = next(i for i, line in enumerate(serial) if "leaves no memory behind" in line)
    startup = sum(line.startswith("  pass ") for line in serial[:end_startup+1])
    final = sum(line.startswith("  pass ") for line in serial)
    shutdown = result.get("shutdown") or next(e["data"] for e in result["events"] if e["event"] == "SHUTDOWN")
    assert (startup, final, result["exit_code"]) == (71, 72, 0)
    assert shutdown == {"guest": True, "reason": "guest-shutdown"}
    checks = {n+".ppm": h for n,h in result.get("screen_sha256", {}).items()}
    checks.update({n: item["sha256"] for n,item in result.get("screen_checks", {}).items()})
    assert checks and all(digest(folder / n) == h for n,h in checks.items())
    runs[name] = dict(startup=startup, final=final, exit=result["exit_code"], shutdown=shutdown,
                      checked_screen_hashes=len(checks), serial_sha256=digest(folder / "serial.txt"))
    files.update(f for f in folder.iterdir() if f.is_file() and f.suffix in {".ppm", ".txt", ".json"})
vm = read(root / "observed-vm/result.json")
assert vm["read_back_label"] == "cold morning"
assert vm["saved_disk_sha256"] == digest(root / "observed-vm/fixture.raw")
assert vm["saved_disk_sha256"] != vm["first_disk_sha256"]
tree = git(root / "integration", "HEAD^{tree}")
assert tree == "adc48f85500ad6ce62fadf2f3c09461fd0032543"
for name in ["single", "two-app", "vm"]:
    assert (root / f"guest-{name}.exit").read_text().strip() == "0"
result = dict(tester=tester, tree=git(root/"src","HEAD^{tree}"), os_source=os_source,
              source_of_ci_pixel_fixtures=git(root.parent/"a3-settings314/src","HEAD"),
              media={str(f.relative_to(media)):digest(f) for f in sorted(media.rglob("*"))
                    if f.is_file() and f.suffix in {".zip", ".iso", ".json"}},
              live_linux=runs, vm=vm, public_live_cd_workflow=44923783407,
              hosted_frame_job=136905307584, bios_candidate_workflow=44923783322,
              local_rehearsal_tree=tree, withdrawn_checker_exit=1,
              withdrawn_checker_wrong=["guest-640x480-clipped.ppm", "reflow-640x480-complete.ppm"])
(root / "readback.json").write_text(json.dumps(result,indent=2) + "\n")
files.update(root / name for name in ["readback.json", "worker-status.json","boot.sh","rehearse.py","preserve.py",
             "ci-warning.log","base-warning.log","focused-tests.log","rehearsal.log","rehearsal-with-history.log",
             "observed-vm/fixture.raw","observed-vm/result.json"])
files.update(root.glob("guest-*.log"))
files.update(root.glob("guest-*.exit"))
seen = {}
checksums = {f.relative_to(root).as_posix():digest(f) for f in sorted(files)}
(root / "SHA256SUMS").write_text("".join(f"{h}  {n}\n" for n,h in checksums.items()))
checksums["SHA256SUMS"] = digest(root / "SHA256SUMS")
archive = root / "originals.tar.xz"
with tarfile.open(archive,"w:xz",preset=1) as out:
    for name,h in checksums.items():
        file = root / name
        if h in seen:
            entry = out.gettarinfo(str(file),name)
            entry.type, entry.linkname, entry.size = tarfile.LNKTYPE, seen[h], 0
            out.addfile(entry)
        else:
            out.add(file,arcname=name,recursive=False)
            seen[h] = name
# Re-read each unique archived file and require every hard link to a verified member.
import lzma
checked = {}
with lzma.open(archive) as stream, tarfile.open(fileobj=stream, mode="r|") as replay:
    for entry in replay:
        if entry.islnk():
            h = checked[entry.linkname]
        else:
            h = hashlib.file_digest(replay.extractfile(entry),"sha256").hexdigest()
        assert h == checksums[entry.name]
        checked[entry.name] = h
assert checked == checksums
print("Verified",len(checked),"archived files",digest(archive))
