from pathlib import Path
import subprocess
import sys
root = Path(__file__).resolve().parent
tree = root / "integration"
steps = [
    (58, "12af170170462d7175d09b42be2176e749dce43f", "4f8beedfcc9c22eaaf0f721b08973b07da0923dd"),
    (63, "2abeead177d616582db7029561df2e10c95381eb", "cd407f07deac69096a4162a97f739cb4b134be57"),
    (59, "2ead8e06681e9388a7d7508e981ce8506bd95260", "1cbb686a34928970eae890a36c2f6735f2ed1114"),
    (64, "6d72a9fb538222afe4dd4fe5aad65958daadf7da", None),
]
for number, sha, expected_tree in steps:
    subprocess.run(["git","-c","user.name=A3 rehearsal","-c","user.email=a3@localhost","merge","--no-ff","--no-edit",sha],cwd=tree,check=True,stdout=subprocess.DEVNULL)
    result = subprocess.check_output(["git","rev-parse","HEAD^{tree}"],cwd=tree,text=True).strip()
    if expected_tree and result != expected_tree:
        raise ValueError(f"Unexpected tree for #{number}: {result}")
    print(f"After #{number} {sha}: tree {result}",flush=True)
for args in (["test_desktop_screens.py", "-v"], ["check_power_frames.py", root.parent / "a3-settings314" / "src"]):
    subprocess.run([sys.executable, "-B", *args],cwd=tree/"audit/public-live-cd",check=True)
