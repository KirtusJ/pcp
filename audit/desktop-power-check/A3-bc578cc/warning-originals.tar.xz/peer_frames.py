import hashlib,json,lzma,os,runpy,shutil,tarfile,tempfile
from pathlib import Path
root=Path(__file__).resolve().parent
os_src=Path(os.environ.get('PCP_COMPACT_OS',root.parent/'a3-settings314/src'))
new=root/'src'
old=Path(os.environ.get('PCP_BASE_TESTER',root.parent/'a3-mapper318/distribution'))
readers=[runpy.run_path(str(s/'audit/public-live-cd/desktop_screens.py'))['DesktopScreens'](os_src,{}) for s in (old,new)]
all_sizes={}
decoder=runpy.run_path(str(os_src/'examples/tester-cd/check_compact_pins.py'))['read']
pairs={'B3-native-settings-8979270':'88c0447b3b9d67e0423da7dd9ad4d04d016e45e7b123af468a9aa24689dba3de','B3-Settings-width-height-8979270':'bf154d0629df668b9f37a90a7369f91d66b5f357ffbaf281e1650001ed34180b'}
for stem,expected in pairs.items():
    file=root/(stem+'.tar.xz')
    assert hashlib.sha256(file.read_bytes()).hexdigest()==expected
    with tempfile.TemporaryFile() as raw:
        with lzma.open(file) as compressed:shutil.copyfileobj(compressed,raw)
        raw.seek(0)
        with tarfile.open(fileobj=raw,mode='r:') as t:
            for name in t.getnames():
                if not name.endswith('/power.ppm'):continue
                data=t.extractfile(name).read()
                mode=Path(name).parent.name
                assert mode not in all_sizes
                rows=decoder(data,readers[0].glyphs)
                all_sizes[mode]=dict(artifact=stem,sha256=hashlib.sha256(data).hexdigest(),base=readers[0].matches(data,'power'),candidate=readers[1].matches(data,'power'),text=[s.strip() for s in rows if s.strip()])
assert len(all_sizes)==12
assert sorted(k for k,r in all_sizes.items() if r['base'])==['640x480','800x600']
assert [k for k,r in all_sizes.items() if r['candidate']]==['800x600']
(root/'peer-frames.json').write_text(json.dumps(dict(archives=pairs,cases=all_sizes),indent=2)+'\n')
print(len(all_sizes),'captures;',[(k,r['base'],r['candidate']) for k,r in all_sizes.items() if r['base']])
