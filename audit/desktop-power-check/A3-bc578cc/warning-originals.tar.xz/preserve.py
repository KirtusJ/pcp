import hashlib,json,subprocess,tarfile,tempfile
from pathlib import Path
root=Path(__file__).resolve().parent
def sha(path):
    with path.open('rb') as f:
        return hashlib.file_digest(f,'sha256').hexdigest()
def read(path):return json.loads(path.read_bytes())
def rev(repo,ref):
    return subprocess.check_output(['git','-C',repo,'rev-parse',ref],text=True).strip()
def digest_named_in_boot(folder):
    serial=(folder/'serial.txt').read_text().splitlines()
    start=next(i for i,s in enumerate(serial) if 'leaves no memory behind' in s)
    return sum(s.startswith('  pass ') for s in serial[:start+1]),sum(s.startswith('  pass ') for s in serial)
boot={}
for name in ['observed-single','observed-two-app','observed-vm/first','observed-vm/cold']:
    folder=root/name
    r=read(folder/'result.json')
    counts=digest_named_in_boot(folder)
    shutdown=r.get('shutdown') or next(e['data'] for e in r['events'] if e['event']=='SHUTDOWN')
    assert counts==(71,72) and r['exit_code']==0 and shutdown=={'guest':True,'reason':'guest-shutdown'}
    boot[name]=dict(startup=counts[0],final=counts[1],exit=0,shutdown=shutdown,serial_sha256=sha(folder/'serial.txt'))
    for n,h in r.get('screen_sha256',{}).items():assert sha(folder/(n+'.ppm'))==h
    for n,c in r.get('screen_checks',{}).items():assert sha(folder/n)==c['sha256']
vm=read(root/'observed-vm/result.json')
assert sha(root/'observed-vm/fixture.raw')==vm['saved_disk_sha256'] and vm['read_back_label']=='cold morning'
hosts=['ubuntu-24.04','macos-15','windows-2025']
for host in hosts:
    cases=read(root/(host+'.json'))['cases']
    assert len(cases)==24 and all(v['base'] and v['candidate'] for v in cases.values())
controls=read(root/'controls/result.json')
assert len(controls['rejected'])==20
r=dict(tester=rev(root/'src','HEAD'),tree=rev(root/'src','HEAD^{tree}'),parent=rev(root/'src','HEAD^'),archived_workflow=44899266193,
    archived_os='3e86beb1ee17fad2f3d61c95b9d5dd017fb6c755',merged_os='89792700243ad5dd4efde3091993984845087e2c',
    historical_power_frames={host:24 for host in hosts},compact=read(root/'compact.json')['cases'],b3=read(root/'peer-frames.json')['cases'],
    offline_controls=controls,live_linux=boot,cold_vm=vm)
(root/'tester-readback.json').write_text(json.dumps(r,indent=2)+'\n')
files=list(root/n for n in ['tester-readback.json','verify.py','warning_controls.py','peer_frames.py','boot.sh','preserve.py','artifacts.json','peer-frames.json','compact.json','worker-status.json','unit.log','controls.log','observed-vm/fixture.raw','observed-vm/result.json']+[h+'.json' for h in hosts])
files.extend((root/'controls').iterdir())
for n in boot:
    files.extend(p for p in (root/n).iterdir() if p.is_file() and p.suffix in {'.txt','.json','.ppm'})
for p in sorted(root.glob('*.exit')):
    assert int(p.read_text())==0
    files.extend([p,p.with_suffix('.log')])
entries={str(f.relative_to(root)):sha(f) for f in files}
seen={}
with tarfile.open(root/'warning-originals.tar.xz','w:xz',preset=1) as t:
    for name,h in entries.items():
        f=root/name
        if h in seen:
            m=t.gettarinfo(str(f),name);m.type=tarfile.LNKTYPE;m.linkname=seen[h];m.size=0;t.addfile(m)
        else:t.add(f,arcname=name,recursive=False);seen[h]=name
with tempfile.TemporaryDirectory() as dest,tarfile.open(root/'warning-originals.tar.xz') as t:
    t.extractall(dest,filter='data')
    assert all(sha(Path(dest)/name)==h for name,h in entries.items())
print(len(entries),'files checked',sha(root/'warning-originals.tar.xz'))
