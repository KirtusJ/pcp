"""Replay the three original host archives and all seven cold-boot captures with both tester revisions."""
from pathlib import Path
import hashlib,json,runpy,subprocess,sys,zipfile
root=Path(__file__).resolve().parent
def revision(repo):
    return subprocess.check_output(['git','-C',repo,'rev-parse','HEAD'],text=True).strip()
def sha(raw):return hashlib.sha256(raw).hexdigest()
old=root.parent/'a3-mapper318/distribution'
new=root/'src'
compact=root.parent/'a3-settings314'
matrix=Path('/workspace/scratch/7c7df1723510/work/a3-hosts-2abe')
historical=matrix.parent/'integrated307'
assert revision(historical)=='3e86beb1ee17fad2f3d61c95b9d5dd017fb6c755'
assert revision(compact/'src')=='89792700243ad5dd4efde3091993984845087e2c'
assert revision(new)=='bc578ccf630a7b4f1d88954151ed07c73eec05c3'
assert revision(old)=='2abeead177d616582db7029561df2e10c95381eb'
def read_power(checkout,src):
    return runpy.run_path(str(checkout/'audit/public-live-cd/desktop_screens.py'))['DesktopScreens'](src,{})
def pair(os_source):
    return [read_power(checkout,os_source) for checkout in (old,new)]
# A repeated frame is read once per checker. Every path is separately compared with its signed-in artifact and receipt.
def check(data,readers,cache):
    h=sha(data)
    if h not in cache:cache[h]=[r.matches(data,'power') for r in readers]
    return dict(sha256=h,base=cache[h][0],candidate=cache[h][1])
run=sys.argv[1]
cache={}
if run=='compact':
    readers=pair(compact/'src')
    cases={}
    for m in ['320x200','320x220','320x240','320x260','320x280','640x480','800x600']:
        cases[m]=check((compact/m/'power.ppm').read_bytes(),readers,cache)
    assert [k for k,v in cases.items() if v['base']]==['640x480','800x600']
    assert [k for k,v in cases.items() if v['candidate']]==['800x600']
else:
    name='desktop-candidate-'+run
    archive=matrix/(name+'.zip')
    description=next(a for a in json.loads((root/'artifacts.json').read_text()) if a['name']==name)
    assert description['workflow_run']['id']==44899266193
    assert description['digest']=='sha256:'+sha(archive.read_bytes())
    readers=pair(historical)
    cases={}
    with zipfile.ZipFile(archive) as z:
        for profile in ('single','two-app','vm/first','vm/cold'):
            result=json.loads(z.read(profile+'/result.json'))
            if profile.startswith('vm/'):
                names=[(path,rec['sha256']) for path,rec in result['screen_checks'].items() if rec['surface']=='power']
                assert len(names)==2
            else:
                assert result['source_commit']==revision(historical)
                names=[(n+'.ppm',h) for n,h in result['screen_sha256'].items() if n.endswith('-power') or n in {'held-enter-after-repeat','held-enter-after-release','mixed-enter-other-released','mixed-enter-after-repeat','mixed-enter-after-release','confirm-shutdown'}]
                assert len(names)==10
            for path,expected in names:
                key=profile+'/'+path
                r=check(z.read(key),readers,cache)
                assert r['sha256']==expected and r['base'] and r['candidate']
                cases[key]=r
    assert len(cases)==24
(root/(run+'.json')).write_text(json.dumps(dict(base=revision(old),candidate=revision(new),cases=cases),indent=2)+'\n')
print(run,len(cases),sum(c['candidate'] for c in cases.values()))
