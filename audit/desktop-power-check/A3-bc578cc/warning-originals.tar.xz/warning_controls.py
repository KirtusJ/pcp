"""Wrap genuine glyphs from the 800-pixel warning onto a copy of the 640-pixel capture."""
import hashlib,json,runpy,textwrap
from pathlib import Path
import numpy as np
root=Path(__file__).resolve().parent
captures=root.parent/'a3-settings314'
reader=runpy.run_path(str(root/'src/audit/public-live-cd/desktop_screens.py'))['DesktopScreens'](captures/'src',{})
def picture(path):
    raw=path.read_bytes()
    magic,dim,depth,body=raw.split(b'\n',3)
    width,height=map(int,dim.split())
    assert magic==b'P6' and depth==b'255'
    return np.frombuffer(body,dtype=np.uint8).reshape(height,width,3),b'\n'.join((magic,dim,depth,b''))
large,unused=picture(captures/'800x600/power.ppm')
base,header=picture(captures/'640x480/power.ppm')
rows=json.loads((captures/'800x600/decoded.json').read_bytes())['power']
complete=' '.join(rows[i].strip() for i in (5,6))
assert complete=='The register is closed and verified first. Files of this session that were not saved by a program are lost.'
glyph={}
for i in (5,6):
    for j,char in enumerate(rows[i]):
        cell=large[i*20:(i+1)*20,j*10:(j+1)*10]
        if char in glyph:assert np.array_equal(cell,glyph[char])
        glyph[char]=cell
words=complete.split()
def paint(text):
    frame=base.copy()
    frame[5*20:8*20,:,:]=base[5*20,0]
    for i,line in enumerate(textwrap.wrap(text,width=62)):
        for j,char in enumerate(line,2):frame[(5+i)*20:(6+i)*20,j*10:(j+1)*10]=glyph[char]
    return header+frame.tobytes()
full=paint(complete)
assert reader.matches(full,'power')
out=root/'controls'
out.mkdir(exist_ok=True)
(out/'complete-reflow.ppm').write_bytes(full)
negative=[]
for i,word in enumerate(words):
    data=paint(' '.join(words[:i]+words[i+1:]))
    assert not reader.matches(data,'power'),(i,word)
    negative.append(dict(index=i,removed=word,sha256=hashlib.sha256(data).hexdigest()))
    if word=='not':(out/'missing-not.ppm').write_bytes(data)
(out/'result.json').write_text(json.dumps(dict(kind='offline images made from genuine captured glyphs',complete_sha256=hashlib.sha256(full).hexdigest(),rejected=negative),indent=2)+'\n')
print('complete wrap accepted;',len(negative),'single-word omissions rejected')
